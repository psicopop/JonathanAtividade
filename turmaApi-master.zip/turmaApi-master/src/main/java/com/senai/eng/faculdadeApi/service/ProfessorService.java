package com.senai.eng.faculdadeApi.service;

import com.senai.eng.faculdadeApi.model.Aluno;
import com.senai.eng.faculdadeApi.model.Professor;
import com.senai.eng.faculdadeApi.repository.ProfessorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;

@Service
public class ProfessorService {

    @Autowired
    private ProfessorRepository repository;

    public List<Professor> findAll() {
        return this.repository.findAll();
    }

    public Professor findById(Integer id) {
        return this.repository.findById(id).orElseThrow();
    }

    public Professor save(Professor aluno) {
        return this.repository.save(aluno);
    }

    public Professor update(Professor professor) {

        if (professor.getId() == null){
            throw new NoSuchElementException("Aluno inexistente");
        }
        return this.repository.save(professor);
    }

    public void delete(Integer id) {
        this.repository.deleteById(id);
    }
}
