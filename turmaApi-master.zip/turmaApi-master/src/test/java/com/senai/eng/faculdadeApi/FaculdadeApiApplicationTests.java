package com.senai.eng.faculdadeApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FaculdadeApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
